// import React from 'react';

const Footer = () =>{
  return(
    <div>
      <span className='text-muted'>Telefonas +370 60456098</span>
      <span className='text-muted'>All Rights Reserved 2023 @DanieliusMatiukas</span>
    </div>
  )
}

export default Footer;