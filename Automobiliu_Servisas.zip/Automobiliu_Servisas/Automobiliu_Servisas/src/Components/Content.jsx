// import React from 'react';
// import './Com'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

const newLocal = () => {
  return (
    <div>
      <main className='body'>
        <Row>
          <Col>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant='top' src='./public/automobiliu_mechanikas_radas_mariunaitis.jpg' />
              <Card.Body>
                <Card.Title>Mechanikas Radas Mariūnaitis</Card.Title>
                <Card.Text>
                  13 patirties metų. Darbo miestas: Šiauliai.
                </Card.Text>
                <span id='rateMe2' className='empty-stars'></span>
                  <script src='js/addons/rating.js'></script>
                <Button variant='primary'>Užsakytį paslaugas</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant='top' src='./public/automobiliu_mechanikas_andrejus_vaiciunas.jpg' />
              <Card.Body>
                <Card.Title>Mechanikas Andrejus Vaičiūna</Card.Title>
                <Card.Text>
                  7 patirties metai. Darbo miestas: Vilnius.
                </Card.Text>
                <span id='rateMe2' className='empty-stars'></span>
                  <script src='js/addons/rating.js'></script>
                <Button variant='primary'>Užsakytį paslaugas</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col>
            <Card style={{ width: '18rem' }}>
              <Card.Img variant='top' src='./public/automobiliu_mechanikas_vainius_andriusavicius.jpg' />
              <Card.Body>
                <Card.Title>Mechanikas Vainius Andriuškėvičius</Card.Title>
                <Card.Text>
                  5 patirties metai. Darbo miestas: Klaipėda.
                </Card.Text>
                <span id='rateMe2' className='empty-stars'></span>
                  <script src='js/addons/rating.js'></script>
                <Button variant='primary'>Užsakytį paslaugas</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </main>
    </div>
  );
};
const Body = newLocal;

export default Body;
